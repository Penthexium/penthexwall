var fs = require("fs");


    function t(e, n) {
        var a = r();
        return (t = function(e, t) {
            return a[e -= 176]
        })(e, n)
    }
    var n = t;

    function r() {
        var e = ["replace", "miny", "inputmember", "imageSmoothingEnabled", "move", "shownametags", "10px Special", "smoothcursors", "GET", "lastedit", "#FFB470", "deletepassword", "writeText", "getElementById", "rgba(239, 255, 71, 0.5)", "iPad", "confirm", "select", " (disconnected)", "deletewall", "userAgent", "delaccountform", "parseFont", "fillRect", "string", "maxx", "stroke", "protectOwner", "toString", "iPod", "transform", "fromCodePoint", "pageY", "light teal", "pushState", "clear", "content", "toast", "getDate", "type", "deltaX", "canvas", "addmemberbtn", "Click here to reconnect.", "Your username is now: ", "space-between", "pointercancel", "empty", "pow", "AEIOU", "copydecorations", "disableColour", "#6D001A", "push", "passchanged", "translate", "alert", "italic 10px ", "isTrusted", "value", "offset", "#51E9F4", "clr", "secondary", "accountsettings", "byteOffset", "true", "pink", "italic bold 10px ", "black", "font", "Select an area to copy.", "pathname", "~main", "slice", "defineProperty", "#FF3881", "px ", " nearby", "registerbtn", "#00CCC0", "light blue", "addmembers", "wrongpass", "alerttext", "div", "multiple", "clipboardData", "unread", "pointerup", "memberlist", "readText", "#7EED56", "loginfail", "#FFA800", "alt", "Private", "title", "/static/fonts/fixed.hex", "add", "justifyContent", "Connection lost.", "remove", "setAttribute", "opacity", "substring", "dec", "scale", "texttheme", "msgpack array:", "msgcontainer", "Fixed", "disablecolour", "random", "customfont", "'s walls", "newpass", "#00A368", "rainbow", "block", "Invalid wall name", "test", "altKey", "password", "/static/copy.svg", "iPhone", "resize", "rgba(255, 255, 255, 0.2)", "/static/sun.svg", "top", "crosshair", "/static/moon.svg", "copy", "\n\n\n\n\n\n\n\n\n", "noreg", "setFloat64", "#6A5CFF", "img", "green", "fillStyle", "status", "function", "setItem", "changepassform", "deleteaccount", "Create", "dark blue", "submitpasschange", "txt", "setTransform", "beginPath", "now", "isArray", "scrollTop", "showothercurs", "accountdeleted", "host", "submit", "dark teal", "#94B3FF", "previousSibling", "/static/lock_open.svg", "#6D482F", "minx", "brown", "invalidTypeReplacement", "touchstart", "Array.prototype.indexOf called on null or undefined", "#FFFFFF", "getTime", "prototype", "startsWith", "captchabox", "abc", "edge", "#B44AC0", "includes", "deleteContentBackward", "size", "#000000", "Unifont", "highlighted", "hideCursors", "keydown", "placeholder", "deletename", "#2450A4", "width", "#FF4500", "quadraticCurveTo", "number", "lineTo", "getFloat64", "then", "checkbox", "copyico", "Your account has been deleted.", "#898D90", "namechanged", "getMilliseconds", "drawText", "customtheme", "getFloat32", "touches", "pointerId", "connecting", "invalid hex length", "smoothpanning", "Password has been changed.", "themetext", "underline", "maxy", "selected", "Custom", "wss://", "target", "toasting", "1161616eUMIgv", "backgroundColor", " online", "-20,-10", "Username is invalid.", "bold 10px ", "alphabetic", "connecting2", "#811E9F", "hidecursors", "#222222", "pale purple", "\\p{Extended_Pictographic}", "You cannot add more than 20 members.", "theme-colour", "tpx", "style", "chngeusrpass", "open", "span", "fontmenu", " ~ ", "#9C6926", "onopen", "moveTo", "#292929", "logoutlink", "http", "loggedin", "flex", "change", "/static/done.svg", "dpr", "red", "chat", "#3690EA", "measureText", "textAlign", "length", "onclose", "shift", "copycolour", "keyCode", "keys", "rgba(204,204,204,0.5)", "main", "fontselect", "grey", "/static/lock.svg", ", monospace", ": (", "disablebraille", "217761RhJHgk", "dataset", "teleport", "addmem", "pop", "closeteleport", "form", "replaceState", "chat to ", "walllist", "split", "purple", "4811232QwKABN", "zoom", "blue", "/ws", "col", "options", "Please type a new username.", "sendmsg", "substr", "exportFont", "strikethrough", "splice", "Passwords do not match.", "getElementsByClassName", "clipboard", "Please complete the captcha below.", "readyState", "Please type your new password.", "burgundy", "rawy", "loginpass", "childElementCount", "name", "thememenu", "deletewallconfirm", "100%", "deltaY", "chat to nobody", "blur", "wheel", "clientY", "tpcoordgo", "insertFromPaste", "protected", "buttonlink", "click", "binaryType", "floor", "light green", "parse", "26602304kHywlV", "userSelect", "from", "themeico", "undefined", "roundRect", "refresh", "pointerdown", "innerHTML", "send", "orange", "max", "display", "#DE107F", "#00CC78", "coords", "none", "lavender", "showchat", "hidden", "toUpperCase", "Deleting wall...", "rgb(", "charMap", "touchend", "fillText", "object", "input", "Password is incorrect.", "Terminus", "You have typed in your current username.", "lineWidth", "CONNECTING", "sign", "getContext", "77dbqUBO", "checked", "10px ", "src", "end", "protect", "91194uQQfaa", "forceSharpPixels", "createTextNode", "admin", "values", "show", "addEventListener", "onclick", "sqrt", "innerText", "dblclick", "data", "removeChild", "connecting1", "italic", "dark brown", "button", "log", "rgba(0,120,212,0.5)", "insertBefore", "oldpass", "appendChild", "cursor", "responseText", "info", "getItem", "theme", "tokenfail", "decorations", "bmp", "createElement", "/static/fonts/unifont-15.0.01.hex", " other users", "children", "classList", "charCodeAt", "2116352KbyRgs", "bold", "tagName", "delete", "Connecting...", "BCDFGHJKLMNPQRSTVWXYZ", "Please type a password.", "selectionEnd", "christmas", "offsetTop", "#E4ABFF", "[object Function]", "requestAnimationFrame", "Invalid code point: ", "contains", "pageX", "magenta", "member", "text", "goto", "Firefox", "password2", "indigo", "protectowner", "left", "fill", "textwall", "#009EAA", "paste", "registerlink", "textarea", "#FF99AA", "drawChar", "message", "height", "fromCharCode", "cool", "focus", "round", "This wall is in read-only mode.", "monospace", "disableChat", "pointerleave", "rawx", "maxLength", "ontouchstart", "Create a new wall", "Copied selection.", "padStart", "chatbox", "rgba(221,249,255,0.5)", "readonly", ", monospace, Special", "disabled", "chat to 1 other user", "0.2", "clientHeight", "apply", "drawImage", "false", "Array.from requires an array-like object - not null or undefined", "onmessage", "px)", "freename", "Registration is closed.", "min", "Copied character.", "Please type your username.", "chngusername", "color", "italic ", "changenameform", "fontSize", "wallsettings", "chatmsg", "dcl", "OPEN", "chunks", "perms", "parentNode", "start", "optionsmenu", "toLowerCase", "codePointAt", "msg", "#FFF8B8", "removeItem", "closemenu", "type 'confirm' here", "shiftKey", "contextmenu", "register", "online", "protectowneroption", "unshift", "fetchFont", "username", "subarray", "New passwords do not match.", "token", "private", "#00756F", "boolean", "call", "/static/fonts/terminus.hex", "clientWidth", "execCommand", "login", "Please type 'confirm' in the text box if you would like to delete your wall.", "sort", "innerWidth", "strokeStyle", "newpass2", "customfontsize", "parentElement", "onreadystatechange", "nextSibling", "readOnly", "CLOSED", "anonymous", "disableBraille", "indexOf", "getData", "enabled", "4415380kSAaWE", "priv", "primary", "ceil", "scrollHeight", "recaptcha", "has", "onerror", "Array.from: when provided, the second argument must be a function", "#515252", "href", "Please type your password.", "bold ", "accsettinglink", "loginbtn", "dark green", "abs", "nametaken", "all", "protocol", "stringify", "get", "submitnamechange", "tpy", "tpword", "admintable", "&y=", "OffscreenCanvas", "pale yellow", "inputType", "getMonth", "clientX", "ctrlKey", "set", "usermenu", "preventDefault", "nearby", "lastElementChild", "innerHeight", "loginname"];
        return (r = function() {
            return e
        })()
    }(function(e, n) {
        for (var r = t, a = e();;) try {
            if (740612 === parseInt(r(654)) / 1 + parseInt(r(273)) / 2 + -parseInt(r(706)) / 3 + parseInt(r(718)) / 4 + parseInt(r(397)) / 5 + parseInt(r(237)) / 6 * (-parseInt(r(231)) / 7) + -parseInt(r(196)) / 8) break;
            a.push(a.shift())
        } catch (e) {
            a.push(a.shift())
        }
    })(r)




var data = fs.readFileSync("./textwall-origin.js").toString("utf8");

var matchLtr = "eantcorilwy";
var alpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
var num = "0123456789";

var buffer = "";

var funcBuffer = "";
var funcRawBuffer = "";
var funcMode = 0;
var chrBefore = "";

for(var i = 0; i < data.length; i++) {
	var chr = data[i];
	if(funcMode == 0 && matchLtr.includes(chr) && !alpha.includes(chrBefore)) {
		funcMode = 1;
		funcRawBuffer += chr;
	} else if(funcMode == 1) {
		if(chr == "(") {
			funcMode = 2;
			funcRawBuffer += chr;
		} else {
			funcMode = 0;
			buffer += funcRawBuffer + chr;
			funcRawBuffer = "";
		}
	} else if(funcMode == 2) {
		if(chr == ")") {
			funcMode = 0;
			var strdata = t(funcBuffer);
			if(strdata === void 0) {
				buffer += funcRawBuffer + chr;
			} else {
				buffer += JSON.stringify(strdata);
			}
			funcBuffer = "";
			funcRawBuffer = "";
		} else {
			if(num.includes(chr)) {
				funcBuffer += chr;
				funcRawBuffer += chr;
			} else {
				funcMode = 0;
				buffer += funcRawBuffer + chr;
				funcBuffer = "";
				funcRawBuffer = "";
			}
		}
	} else {
		buffer += funcRawBuffer;
		funcRawBuffer = "";
		buffer += chr;
	}
	chrBefore = chr;
}

fs.writeFileSync("./textwalldeco.js", buffer);