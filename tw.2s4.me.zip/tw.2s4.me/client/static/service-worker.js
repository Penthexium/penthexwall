self.addEventListener('install', function() {});
self.addEventListener("activate", event=>{}
);
self.addEventListener('fetch', function(event) {});
